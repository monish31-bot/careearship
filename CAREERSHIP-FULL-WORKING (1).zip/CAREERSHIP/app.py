import os, re, time, threading
from datetime import datetime, timedelta, timezone
from functools import wraps
from urllib.parse import urlparse

import requests
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_URL = os.getenv('DATABASE_URL', f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'careership.db')}")
if DB_URL.startswith('postgres://'):
    DB_URL = DB_URL.replace('postgres://', 'postgresql://', 1)

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv('SECRET_KEY', 'change-this-careership-secret-in-production'),
    SQLALCHEMY_DATABASE_URI=DB_URL,
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    JSON_SORT_KEYS=False,
)
db = SQLAlchemy(app)

LIVE_APIS = {
    'arbeitnow': 'https://www.arbeitnow.com/api/job-board-api',
    'remotive': 'https://remotive.com/api/remote-jobs',
}
SYNC_TTL_MINUTES = int(os.getenv('SYNC_TTL_MINUTES', '30'))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(180), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    course = db.Column(db.String(120), default='')
    year = db.Column(db.String(30), default='')
    skills = db.Column(db.Text, default='')
    interests = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Opportunity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    external_id = db.Column(db.String(300), unique=True, nullable=False)
    title = db.Column(db.String(300), nullable=False)
    company = db.Column(db.String(220), default='Unknown organization')
    location = db.Column(db.String(300), default='Remote')
    category = db.Column(db.String(80), default='Opportunity')
    job_type = db.Column(db.String(80), default='')
    description = db.Column(db.Text, default='')
    skills = db.Column(db.Text, default='')
    source = db.Column(db.String(80), nullable=False)
    source_url = db.Column(db.Text, nullable=False)
    published_at = db.Column(db.String(80), default='')
    fetched_at = db.Column(db.DateTime, default=datetime.utcnow)

class Saved(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    opportunity_id = db.Column(db.Integer, db.ForeignKey('opportunity.id'), nullable=False)
    __table_args__ = (db.UniqueConstraint('user_id', 'opportunity_id', name='uq_saved'),)

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    opportunity_id = db.Column(db.Integer, db.ForeignKey('opportunity.id'), nullable=False)
    status = db.Column(db.String(40), default='Interested')
    notes = db.Column(db.Text, default='')
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint('user_id', 'opportunity_id', name='uq_application'),)

class SyncState(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    source = db.Column(db.String(80), unique=True, nullable=False)
    last_sync = db.Column(db.DateTime, default=datetime.utcnow)
    item_count = db.Column(db.Integer, default=0)
    status = db.Column(db.String(30), default='ok')


def clean_html(text):
    return re.sub(r'<[^>]+>', ' ', text or '').replace('&nbsp;', ' ').strip()

def infer_category(title, description=''):
    t = (title + ' ' + description).lower()
    if any(x in t for x in ['intern', 'internship', 'trainee']): return 'Internship'
    if any(x in t for x in ['scholarship', 'fellowship', 'grant']): return 'Scholarship'
    if any(x in t for x in ['hackathon', 'competition', 'challenge']): return 'Hackathon'
    if any(x in t for x in ['research', 'researcher']): return 'Research'
    if any(x in t for x in ['graduate', 'campus', 'entry level', 'junior']): return 'Graduate'
    return 'Job'

def normalize_tags(title, description):
    text = (title + ' ' + description).lower()
    tags = []
    mapping = {
        'python': 'Python', 'javascript': 'JavaScript', 'typescript': 'TypeScript',
        'react': 'React', 'next.js': 'Next.js', 'java': 'Java', 'sql': 'SQL',
        'machine learning': 'Machine Learning', 'artificial intelligence': 'AI',
        'data science': 'Data Science', 'flask': 'Flask', 'django': 'Django',
        'node.js': 'Node.js', 'aws': 'AWS', 'docker': 'Docker', 'figma': 'Figma',
    }
    for needle, tag in mapping.items():
        if needle in text: tags.append(tag)
    return ', '.join(tags[:10])

def upsert_opportunity(data):
    obj = Opportunity.query.filter_by(external_id=data['external_id']).first()
    if not obj:
        obj = Opportunity(external_id=data['external_id'])
        db.session.add(obj)
    for k, v in data.items(): setattr(obj, k, v)
    obj.fetched_at = datetime.utcnow()
    return obj

def fetch_arbeitnow():
    r = requests.get(LIVE_APIS['arbeitnow'], timeout=15, headers={'User-Agent': 'Careership/1.0'})
    r.raise_for_status()
    payload = r.json()
    items = payload.get('data', [])
    out = []
    for x in items[:80]:
        title = x.get('title', 'Untitled opportunity')
        desc = clean_html(x.get('description', ''))
        url = x.get('url') or ''
        if not url: continue
        out.append(dict(
            external_id='arbeitnow:' + str(x.get('slug') or x.get('id') or url),
            title=title, company=x.get('company_name') or 'Organization',
            location=x.get('location') or ('Remote' if x.get('remote') else 'Not specified'),
            category=infer_category(title, desc), job_type=x.get('job_types', [''])[0] if isinstance(x.get('job_types'), list) and x.get('job_types') else '',
            description=desc[:9000], skills=normalize_tags(title, desc), source='Arbeitnow', source_url=url,
            published_at=x.get('created_at') or '',
        ))
    return out

def fetch_remotive():
    r = requests.get(LIVE_APIS['remotive'], timeout=15, headers={'User-Agent': 'Careership/1.0'})
    r.raise_for_status()
    payload = r.json()
    out = []
    for x in payload.get('jobs', [])[:80]:
        title = x.get('title', 'Untitled opportunity')
        desc = clean_html(x.get('description', ''))
        url = x.get('url') or ''
        if not url: continue
        out.append(dict(
            external_id='remotive:' + str(x.get('id') or url),
            title=title, company=x.get('company_name') or 'Organization',
            location=', '.join(x.get('candidate_required_location') or []) or 'Remote',
            category=infer_category(title, desc), job_type=x.get('job_type') or '',
            description=desc[:9000], skills=normalize_tags(title, desc), source='Remotive', source_url=url,
            published_at=x.get('publication_date') or '',
        ))
    return out

def sync_source(source):
    try:
        items = fetch_arbeitnow() if source == 'arbeitnow' else fetch_remotive()
        for item in items: upsert_opportunity(item)
        state = SyncState.query.filter_by(source=source).first() or SyncState(source=source)
        state.last_sync = datetime.utcnow(); state.item_count = len(items); state.status = 'ok'
        db.session.add(state); db.session.commit()
        return len(items), None
    except Exception as e:
        db.session.rollback()
        state = SyncState.query.filter_by(source=source).first() or SyncState(source=source)
        state.status = 'error'; state.last_sync = datetime.utcnow(); db.session.add(state); db.session.commit()
        return 0, str(e)

def sync_if_stale(force=False):
    with app.app_context():
        now = datetime.utcnow()
        states = {s.source: s for s in SyncState.query.all()}
        for source in LIVE_APIS:
            stale = source not in states or not states[source].last_sync or (now - states[source].last_sync) > timedelta(minutes=SYNC_TTL_MINUTES)
            if force or stale:
                sync_source(source)

def current_user():
    uid = session.get('user_id')
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash('Please sign in to continue.', 'info')
            return redirect(url_for('login', next=request.path))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_globals():
    return {'user': current_user(), 'site_name': 'Careership', 'founder': 'Monish', 'year_now': datetime.now().year}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name','').strip()
        email = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        course = request.form.get('course','').strip()
        year = request.form.get('year','').strip()
        if not name or not email or len(password) < 8:
            flash('Enter your name, valid email and a password of at least 8 characters.', 'error')
            return render_template('register.html')
        if User.query.filter_by(email=email).first():
            flash('An account with this email already exists.', 'error')
            return render_template('register.html')
        u = User(name=name, email=email, password_hash=generate_password_hash(password), course=course, year=year)
        db.session.add(u); db.session.commit(); session['user_id'] = u.id
        flash('Welcome to Careership. Your account is ready.', 'success')
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email','').strip().lower(); password = request.form.get('password','')
        u = User.query.filter_by(email=email).first()
        if not u or not check_password_hash(u.password_hash, password):
            flash('Email or password is incorrect.', 'error'); return render_template('login.html')
        session['user_id'] = u.id
        return redirect(request.args.get('next') or url_for('dashboard'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    sync_if_stale()
    u = current_user(); latest = Opportunity.query.order_by(Opportunity.fetched_at.desc()).limit(8).all()
    saved_count = Saved.query.filter_by(user_id=u.id).count(); app_count = Application.query.filter_by(user_id=u.id).count()
    return render_template('dashboard.html', opportunities=latest, saved_count=saved_count, app_count=app_count)

@app.route('/opportunities')
def opportunities():
    sync_if_stale()
    q = request.args.get('q','').strip(); category = request.args.get('category','').strip(); source = request.args.get('source','').strip()
    query = Opportunity.query
    if q:
        like = f'%{q}%'; query = query.filter(db.or_(Opportunity.title.ilike(like), Opportunity.company.ilike(like), Opportunity.skills.ilike(like), Opportunity.location.ilike(like)))
    if category: query = query.filter_by(category=category)
    if source: query = query.filter_by(source=source)
    items = query.order_by(Opportunity.fetched_at.desc()).limit(100).all()
    saved_ids = {s.opportunity_id for s in Saved.query.filter_by(user_id=session.get('user_id')).all()} if session.get('user_id') else set()
    return render_template('opportunities.html', opportunities=items, saved_ids=saved_ids, q=q, category=category, source=source)

@app.route('/opportunity/<int:oid>')
def opportunity_detail(oid):
    obj = db.session.get(Opportunity, oid) or abort(404)
    saved = bool(session.get('user_id') and Saved.query.filter_by(user_id=session['user_id'], opportunity_id=oid).first())
    return render_template('opportunity.html', opportunity=obj, saved=saved)

@app.route('/saved')
@login_required
def saved():
    rows = Saved.query.filter_by(user_id=session['user_id']).all(); ids = [r.opportunity_id for r in rows]
    items = Opportunity.query.filter(Opportunity.id.in_(ids)).all() if ids else []
    return render_template('saved.html', opportunities=items)

@app.route('/applications')
@login_required
def applications():
    rows = Application.query.filter_by(user_id=session['user_id']).order_by(Application.updated_at.desc()).all()
    data = [(r, db.session.get(Opportunity, r.opportunity_id)) for r in rows]
    return render_template('applications.html', applications=data)

@app.route('/profile', methods=['GET','POST'])
@login_required
def profile():
    u = current_user()
    if request.method == 'POST':
        u.name=request.form.get('name','').strip(); u.course=request.form.get('course','').strip(); u.year=request.form.get('year','').strip(); u.skills=request.form.get('skills','').strip(); u.interests=request.form.get('interests','').strip(); db.session.commit(); flash('Profile updated.', 'success'); return redirect(url_for('profile'))
    return render_template('profile.html')

@app.post('/api/save/<int:oid>')
@login_required
def api_save(oid):
    if not db.session.get(Opportunity, oid): return jsonify(ok=False, error='Opportunity not found'), 404
    row = Saved.query.filter_by(user_id=session['user_id'], opportunity_id=oid).first()
    if row: db.session.delete(row); saved=False
    else: db.session.add(Saved(user_id=session['user_id'], opportunity_id=oid)); saved=True
    db.session.commit(); return jsonify(ok=True, saved=saved)

@app.post('/api/application/<int:oid>')
@login_required
def api_application(oid):
    if not db.session.get(Opportunity, oid): return jsonify(ok=False), 404
    status=request.form.get('status','Interested'); notes=request.form.get('notes','')
    row=Application.query.filter_by(user_id=session['user_id'], opportunity_id=oid).first()
    if not row: row=Application(user_id=session['user_id'], opportunity_id=oid)
    row.status=status; row.notes=notes; row.updated_at=datetime.utcnow(); db.session.add(row); db.session.commit()
    return jsonify(ok=True)

@app.post('/api/sync')
def api_sync():
    # Manual refresh is intentionally public; only pulls public feeds.
    counts={}
    for source in LIVE_APIS: counts[source]=sync_source(source)[0]
    return jsonify(ok=True, counts=counts, at=datetime.now(timezone.utc).isoformat())

@app.get('/api/health')
def health():
    try: db.session.execute(db.text('SELECT 1')); db_ok=True
    except Exception: db_ok=False
    return jsonify(status='ok' if db_ok else 'degraded', database=db_ok, opportunities=Opportunity.query.count())

@app.get('/robots.txt')
def robots():
    base=request.url_root.rstrip('/')
    return f"User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: {base}/sitemap.xml\n", 200, {'Content-Type':'text/plain'}

@app.get('/sitemap.xml')
def sitemap():
    base=request.url_root.rstrip('/')
    urls=[base+'/',base+'/opportunities',base+'/login',base+'/register']
    urls += [base+url_for('opportunity_detail', oid=o.id) for o in Opportunity.query.order_by(Opportunity.id.desc()).limit(100).all()]
    xml='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{u}</loc></url>' for u in urls)+'</urlset>'
    return xml,200,{'Content-Type':'application/xml'}

@app.errorhandler(404)
def not_found(e): return render_template('error.html', code=404, message='The page you are looking for does not exist.'), 404

with app.app_context():
    os.makedirs(os.path.join(BASE_DIR,'instance'), exist_ok=True)
    db.create_all()

if __name__ == '__main__':
    print('CAREERSHIP is starting on http://127.0.0.1:5000')
    app.run(host='0.0.0.0', port=int(os.getenv('PORT','5000')), debug=False)
