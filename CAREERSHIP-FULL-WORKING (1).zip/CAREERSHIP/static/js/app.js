document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('.toast').forEach(t=>setTimeout(()=>t.remove(),4500));
 document.querySelectorAll('.save-btn').forEach(btn=>btn.addEventListener('click',async()=>{const r=await fetch('/api/save/'+btn.dataset.id,{method:'POST'});const d=await r.json();if(d.ok)btn.textContent=d.saved?'Saved ✓':'Save opportunity'}));
 document.querySelectorAll('.apply-form').forEach(form=>form.addEventListener('submit',async e=>{e.preventDefault();const r=await fetch('/api/application/'+form.dataset.id,{method:'POST',body:new FormData(form)});const d=await r.json();if(d.ok){form.querySelector('button').textContent='Added ✓';setTimeout(()=>form.querySelector('button').textContent='Add to tracker',1800)}}));
});
