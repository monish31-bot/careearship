# CAREERSHIP

A professional Flask + PostgreSQL/SQLite student opportunity platform.

## Features
- Student registration/login with hashed passwords
- Profile and preferences
- Live public opportunity synchronization from Arbeitnow and Remotive
- Search and category/source filtering
- Opportunity detail pages with original source links
- Saved opportunities
- Application tracker
- Health endpoint
- SEO metadata, robots.txt and sitemap.xml
- Production Gunicorn configuration
- Render deployment blueprint with PostgreSQL
- Responsive animated/glassmorphism UI

## Local Windows setup
1. Open this folder in VS Code.
2. Open PowerShell.
3. Run `py -m venv .venv`
4. Run `.venv\\Scripts\\Activate.ps1`
5. Run `python -m pip install -r requirements.txt`
6. Run `python app.py`
7. Open http://127.0.0.1:5000

Or double-click `start.bat`.

## Production
Set `SECRET_KEY` and a PostgreSQL `DATABASE_URL`. Start with `gunicorn app:app`.

## Live feeds
The app links back to the original source for each listing. Review each provider's terms before commercial use. Remotive's public API requires attribution/link-back and its public jobs are delayed. Arbeitnow's free API is intended for job-board/side-project use and primarily covers Europe.

## SEO
After deployment, set the canonical/public URL in your SEO strategy, submit `/sitemap.xml` to Google Search Console, and request indexing. A public URL does not guarantee immediate Google ranking/indexing.
